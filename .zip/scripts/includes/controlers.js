import { World, Commands, BlockLocation } from "mojang-minecraft";
import { getScore, numFormatter, runCommand } from "./functions.js";

// Used to make sure only one scoreboard of a objective is in each world